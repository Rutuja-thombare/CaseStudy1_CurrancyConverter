package com.example.currencyconverter

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

//https://api.exchangeratesapi.io/latest?base=USD&symbols=INR

class RetrofitClient {
    interface Api{
        @GET("latest?base=USD&symbols=INR")  // the table name in the url where json data stored https://jsonplaceholder.typicode.com/users
        fun getUser(@Query("base") base1:String,
                    @Query("symbols") symbol: String) : Call<User>
}
    companion object {
        val myRetrofitClient = Retrofit.Builder()   //to build the client to make call to below url
            .baseUrl("https://api.exchangeratesapi.io/")

            .addConverterFactory(GsonConverterFactory.create()) //gson converter factory convert all json data(response) on url into object
            .build()

        val myApi = myRetrofitClient.create(Api::class.java)
        val myCall = myApi.getUser(base1 = "USD",symbol = "INR")    //to make call to server//interface function
    }
}