package com.example.currencyconverter

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_second.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response



class Second : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val makeCall = RetrofitClient.myCall
        makeCall.enqueue(object : Callback<User> { //callbback should be retrofit type

            override fun onResponse(call: Call<User>, response: Response<User>) {
                var rate : Double
                rate = response.body()?.myrate?.INR!!

                buttonConvert.setOnClickListener {

                    var usd = valueUSD.text.toString().toInt()
                    var inr : Float =((usd*rate).toFloat())
                    var res: String = inr.toString()

                    if (usd == null ){
                        Toast.makeText(applicationContext,"please enter number, edit text cannot be blank",Toast.LENGTH_LONG).show()
                    }
                    else{
                        valueINR.setText(res).toString()    //to store the value in txtview using the id
                    }


                }

            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                Log.e("failure","Onfailure")
            }

        } )


        /*buttonConvert.setOnClickListener {

            var usd = valueUSD.text.toString().toInt()
            var inr : Float = (usd*74.6390181972).toFloat()
            var res: String = inr.toString()
            if (usd == null ){
                Toast.makeText(this,"please enter number, edit text cannot be blank",Toast.LENGTH_LONG).show()
            }
            else{
                valueINR.setText(res).toString()    //to store the value in txtview using the id
            }


        }*/

    }   //end oncreate
}

