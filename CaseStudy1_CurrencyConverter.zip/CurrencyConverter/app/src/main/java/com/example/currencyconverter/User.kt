package com.example.currencyconverter

import com.google.gson.annotations.SerializedName

data class User (
        var base : String,
        var date : String,
       @SerializedName("rates") //serializedname is used for instead of searching rates in json file search by myrate of type rate
       var myrate : rates

)

data class rates(var INR : Double)



